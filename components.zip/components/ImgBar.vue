<template>
  <div>
    <div
      class="relative bg-gradient-to-b from-[#070B14] to-transparent h-110 z-50"
    >
      <ul class="flex space-x-6 flex-center h-20">
        <li class="relative group">
          <NuxtLink
            to="/"
            class="text-white flex items-center justify-center px-2 py-1"
          >
            Oyunlar
            <Icon name="mingcute:down-line" class="w-5 h-5 text-white" />
          </NuxtLink>
          <div
            class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#1b9a88] to-[#1C3E7E] opacity-0 group-hover:opacity-100 transition-all duration-300"
          ></div>
        </li>
        <li class="relative group">
          <NuxtLink
            to="/"
            class="text-white flex items-center justify-center px-2 py-1"
          >
            Hediye Kartları
          </NuxtLink>
          <div
            class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#1b9a88] to-[#1C3E7E] opacity-0 group-hover:opacity-100 transition-all duration-300"
          ></div>
        </li>

        <li class="relative group">
          <NuxtLink
            to="/"
            class="text-white flex items-center justify-center px-2 py-1"
          >
            Ödeme Kartları
          </NuxtLink>
          <div
            class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#1b9a88] to-[#1C3E7E] opacity-0 group-hover:opacity-100 transition-all duration-300"
          ></div>
        </li>

        <li class="relative group">
          <NuxtLink
            to="/"
            class="text-white flex items-center justify-center px-2 py-1"
          >
            Kategoriler
          </NuxtLink>
          <div
            class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#1b9a88] to-[#1C3E7E] opacity-0 group-hover:opacity-100 transition-all duration-300"
          ></div>
        </li>

        <li class="relative group">
          <NuxtLink
            to="/"
            class="text-white flex items-center justify-center px-2 py-1"
          >
            Davet Et Kazan
          </NuxtLink>
          <div
            class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#1b9a88] to-[#1C3E7E] opacity-0 group-hover:opacity-100 transition-all duration-300"
          ></div>
        </li>

        <li class="relative group">
          <NuxtLink
            to="/"
            class="text-white flex items-center justify-center px-2 py-1"
          >
            Ödül Çarkı
          </NuxtLink>
          <div
            class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#1b9a88] to-[#1C3E7E] opacity-0 group-hover:opacity-100 transition-all duration-300"
          ></div>
        </li>

        <li class="relative group">
          <NuxtLink
            to="/"
            class="text-white flex items-center justify-center px-2 py-1"
          >
            Bakiye Yükle
          </NuxtLink>
          <div
            class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#1b9a88] to-[#1C3E7E] opacity-0 group-hover:opacity-100 transition-all duration-300"
          ></div>
        </li>
      </ul>
      <NuxtImg src="Artboard1.png" class="w-full absolute  h-100 object-cover" />
    </div>
  </div>
</template>
