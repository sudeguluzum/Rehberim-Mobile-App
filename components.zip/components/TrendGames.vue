<template>
  <div
    class="relative bg-amber-300 h-60 flex flex-col justify-center items-center p-4"
  >
    <div class="text-white text-2xl font-bold mb-4">
      <h1>Trend Oyunlar</h1>
    </div>
    <div class="w-180 h-70 bg-[#070B14] bg-opacity-25">
      <div class="relative w-full">
        <div
          ref="scrollContainer"
          class="flex space-x-5 overflow-x-auto w-full justify-start scrollbar-hide"
        >
          <div
            v-for="(i, index) in images"
            :key="index"
            class="rounded-sm h-40 w-30 flex-shrink-0"
          >
            <NuxtImg :src="i.image" class="h-full w-full object-cover" />
          </div>
        </div>
        <!-- Slider Kontrolleri -->
        <button
          @click="scrollLeft"
          class="absolute left-0 top-1/2 transform -translate-y-1/2 bg-gray-800 text-white p-2 rounded-full"
        >
          &#10094;
        </button>
        <button
          @click="scrollRight"
          class="absolute right-0 top-1/2 transform -translate-y-1/2 bg-gray-800 text-white p-2 rounded-full"
        >
          &#10095;
        </button>
      </div>
    </div>

    <!-- <div class="flex space-x-5 overflow-x-auto w-full justify-center">
    <div
      v-for="(i, index) in images"
      :key="index"
      class="rounded-sm h-40 w-30 flex-shrink-0"
    >
      <NuxtImg :src="i.image" class="h-full w-full object-cover" />
    </div>
  </div> -->
  </div>
</template>
<script setup>
import { ref } from "vue";
const images = [
  { image: "trend_oyun1.png" },
  { image: "trend_oyun2.png" },
  { image: "trend_oyun3.png" },
  { image: "trend_oyun4.png" },
  { image: "trend_oyun5.png" },
  { image: "trend_oyun6.png" },
  { image: "trend_oyun7.png" },
  { image: "trend_oyun8.png" },
  { image: "trend_oyun9.png" },
  { image: "trend_oyun10.png" },
];

const scrollContainer = ref(null);

const scrollLeft = () => {
  if (scrollContainer.value) {
    scrollContainer.value.scrollLeft -= 200;
  }
};

const scrollRight = () => {
  if (scrollContainer.value) {
    scrollContainer.value.scrollLeft += 200;
  }
};
</script>
